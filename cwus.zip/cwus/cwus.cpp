﻿#include <iostream>
#include <fstream>// for files
#include <vector> // for arrays
#include <algorithm>
#include "Observer.h"
#include <C:\Users\Asus\source\repos\single_include\nlohmann\json.hpp>
using json = nlohmann::json;
class word {
private:
    int WordId;
    string WordName;
    int dmg;
    int periodic_dmg;
    int target;
public:
    word(int wordid, string wordname, int Dmg,  int per_dmg, int Target) {
        WordId = wordid;
        WordName = wordname;
        dmg = Dmg;
        periodic_dmg = per_dmg;
        target = Target;
    }
    int getWordId() const {
        return WordId;
    }
    const std::string& getWordName() const {
        return WordName;
    }
    int getDmg() const {
        return dmg;
    }
    int getPeriodicDmg() const {
        return periodic_dmg;
    }
    int getTarget() const {
        return target;
    }
};

class target :public BattleObserver, public BattleSubject{
protected:
    int hp;
    bool evade;
    int periodic_hp_change;
public:
    static std::vector<word*> words;
    void take_damage(int damage) {
        hp -= damage;
    }
    virtual void death() = 0;
    virtual void attack() = 0;
    void update(int wordId){
        periodic_hp_change = words[wordId]->getPeriodicDmg();
        take_dmg(words[wordId]->getDmg());
    }
    target() {
        if (words.size() == 0) {
            std::ifstream in_words("words.json");
            if (!in_words) {
                std::cerr << "Cannot open words.json" << std::endl;
                return;
            }
            json j;
            in_words >> j;
            for (const auto& Word : j) {
                word* w = new word(Word["word_id"], Word["word_name"], Word["dmg"], Word["periodic_dmg"], Word["target"]);
                words.push_back(w);
            }
        }
    }
    void take_dmg(int dmg) {
        hp -= dmg;
        hp -= periodic_hp_change;
        periodic_hp_change -= 1;
    }
    int gethp() {
        return hp;
    }
    void initiate_attack(int wordId) {
        Battlenotify(wordId, words[wordId]->getTarget());
    };
};
std::vector<word*> target::words;
class Room :public RoomObserver,public RoomSubject{
protected:
    int roomid;
    int floor;
    int roomtype;
    Room* room_left = nullptr;
    Room* room_right = nullptr;
    Room* room_up = nullptr;
    Room* room_down = nullptr;
    int room_left_id;
    int room_right_id;
    int room_up_id;
    int room_down_id;
    bool visited;

public:
    static std::vector<Room*> registry;
    Room(const std::string& filename = "room.json") {
        std::ifstream in(filename);
        if (!in.is_open()) {
            std::cerr << "Не удалось открыть " << filename << std::endl;
            return;
        }
        json j;
        in >> j;
        roomid = j[0].value("roomid", 0);
        floor = j[0].value("floor", 0);
        roomtype = j[0].value("roomtype", 0);
        room_left_id = j[0].value("room_left", -1);
        room_right_id = j[0].value("room_right", -1);
        room_up_id = j[0].value("room_up", -1);
        room_down_id = j[0].value("room_down", -1);
        visited = j[0].value("visited", false);
        registry.push_back(this);
    }
    static void link_rooms() {
        for (auto* room : registry) {
            for (auto* other : registry) {
                if (room->room_left_id == other->roomid)   room->room_left = other;
                if (room->room_right_id == other->roomid)  room->room_right = other;
                if (room->room_up_id == other->roomid)     room->room_up = other;
                if (room->room_down_id == other->roomid)   room->room_down = other;
            }
        }
    }
    int get_floor() const {
        return floor;
    }
    const int& get_type() const {
        return roomtype;
    }
    virtual void room_event(Player* player) = 0;
};
std::vector<Room*> Room::registry;


class Player : public target, public RoomSubject{
private:
    std::array<bool, 26> letter_inventory{};  // inventory of letters A-Z
    std::vector<int> scroll_inventory;        // inventory of scroll IDs
    Room* current_room = nullptr;             // pointer to current room
    int money = 0;                            // player's money amount

public:
    void death(){
        std::cout << "Player died" << std::endl;
    }
    void attack(){
        std::cout << "type your word, your letters:" << std::endl;
        for (int i = 0; i < 26;i++) {
            if (letter_inventory[i]) {
                cout << static_cast<char>('A' + i) << " ";
            }
        }cout << "your hp:" << hp << '\n';
        string word;
        cin >> word;
        if (word == "rod") {// will be changed
            Battlenotify(1,1);
        }else {
            std::cout << "not the word or don't have letters" << std::endl;
        }
    }
    void change_room(const std::string& direction) {// for now empty
    }
    void setroom(Room* room) {
        current_room = room;
    }
    Player() {
        std::ifstream in("starterPack.json");
        if (!in.is_open()) {
            std::cerr << "Не удалось открыть starterpack.json" << std::endl;
            return;
        }
        json j;
        in >> j;
        hp = j.value("hp", 20);
        letter_inventory=j["letters"].get<std::array<bool, 26>>();
        scroll_inventory=j["scrolls"].get<std::vector<int>>();
    }
};
class Enemy:public target{
private:
    int EnemyId;
    vector<int> attacks;
    string name;
    // loot later
public:
    Enemy() {// death и attack
        std::ifstream in("enemy.json");
        if (!in.is_open()) {
            std::cerr << "Не удалось открыть enemy.json" << std::endl;
            return;
        }
        json j;
        in >> j;
        EnemyId = j[0]["EnemyId"];
        attacks = j[0]["enemyAttacks"].get<std::vector<int>>();
        name = j[0].value("enemyName","");
    }
    void attack() {
        int attack = (rand() * attacks.size()) % (attacks.size());
        Battlenotify(attacks[attack], words[attacks[attack]]->getTarget());
    }
    void death() {
        cout << "enemy dead" << '\n';
    }

};
class Battle {
private:
    Enemy* enemy;
    bool player_turn;
public:
    Battle(Player* player) {
        delete enemy;
        enemy = new Enemy();
        int result =battleloop(player);
        if (not(result)) {
            cout << "you lost" << '\n';
        }else {
            cout << "you won" << '\n';
        }
        this->~Battle();
    }
    int battleloop(Player* player) {
        player->registerBattleObserver(enemy);
        enemy->registerBattleObserver(player);
        while (enemy->gethp()>0 or player->gethp() > 0) {
            if (player_turn) {
                player->attack();
            }
            else {
                enemy->attack();
            }
        }
        if (enemy->gethp() > 0) {
            return 0;
        }
        else {
            return 1;
        }
    }
    ~Battle() {
        delete enemy;

    }
};
class Enemy_Room :public Room{
private:
    Battle* battle;
public:
    void update(Player* player) {
        if (not(visited)) {
            room_event(player);
            visited = true;
        }
    }
    void room_event(Player* player) {
        battle = new Battle(player);
    }
};

int main() {
    Player player;
    Enemy_Room room;
    player.registerRoomObserver(&room);
    player.Roomnotify(&player);
}